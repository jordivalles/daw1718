<?php

class Application_Model_DbTable_Recursos extends Zend_Db_Table_Abstract
{

    protected $_name = 'recursos';


}

